import logging
import logging

from neo4j_data.database_connect import Neo4jDriverSingleton
from datetime import datetime

class RecommendationService:
    def __init__(self, driver):
        self.driver = driver

    def get_recommended_posts(self, user_id, limit=10):
        logging.critical("RUN Recommendation settings")
        with self.driver.session() as session:
            query = """
MATCH (u:User {id: $user_id})-[i:INTERACTED_WITH]->(p:Post)
WITH u, COLLECT(p.id) AS seen_post_ids

MATCH (rec:Post)
WHERE NOT rec.id IN seen_post_ids

// scor pe baza tagurilor
OPTIONAL MATCH (u)-[int:INTERACTED_WITH]->(:Post)-[:TAGGED_AS]->(t)<-[:TAGGED_AS]-(rec)
WITH rec,
     COALESCE(SUM(int.score), 0) AS score,
     rec.likes AS likes,
     rec.dislikes AS dislikes,
     rec.comments AS comments

RETURN rec.id AS id,
       rec.title AS title,
       rec.content AS content,
       rec.timestamp AS timestamp,
       COALESCE(likes, 0) AS likes,
       COALESCE(dislikes, 0) AS dislikes,
       COALESCE(comments, 0) AS comments,
       score
ORDER BY score DESC, timestamp DESC
LIMIT $limit

            """

            result = session.run(query, user_id=user_id, limit=limit)
            results = []
            for record in result:
                results.append({
                    "id": record["id"],
                    "title": record["title"],
                    "content": record["content"],
                    "timestamp": record["timestamp"],
                    "likes": record["likes"],
                    "dislikes": record["dislikes"],
                    "comments": record["comments"],
                    "author_name": "Recommended",
                    "author_id": "system",
                    "community_name": "",
                    "score": record["score"]
                })
            logging.critical(f"RECOMMENDED POSTS: {results}")
            return results


if __name__ == "__main__":
    Neo4jDriverSingleton(uri="bolt://localhost:7687", user="neo4j", password="12345678")
    posts_repo = RecommendationService(Neo4jDriverSingleton.get_driver())
    posts = posts_repo.get_recommended_posts("38599")
    print(posts)